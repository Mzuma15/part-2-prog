package com.mycompany.programminparttwo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import com.google.gson.Gson;
import java.util.Random;
import java.util.Scanner;

public class Message {

    Scanner scan = new Scanner(System.in);

    /**
     * Displaying the message action options
     */
    public String selectMessageAction(String messageId, String messageText, String messageHash, String recipient) {

        //storing the message options in a 1 d array
        String[] options = {
            "Send Message",
            "Disregard Message",
            "Store Message"
        };

        //displaying the menu to the user
        System.out.println("\nSelect an action:");
        System.out.println("0. Send Message");
        System.out.println("1. Disregard Message");
        System.out.println("2. Store Message");

        System.out.print("User: ");
        int choice = scan.nextInt();
        scan.nextLine();

        //using switch for the menu
        switch (choice) {
            case 0:
                System.out.println("Message successfully sent.");
                displayOnlySentMessages(messageId,messageText,messageHash,recipient);
                break;

            case 1:
                System.out.println("Message disregarded.");
                break;

            case 2:
                storeMessage(messageId, messageText, messageHash, recipient);
                System.out.println("Message stored successfully.");
                break;
        }

        return options[choice];
    }

    /**
     * A method that Generates a random 10-digit message ID
     */
    public String generateMessageId() {
        Random random = new Random();
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < 10; i++) {
            builder.append(random.nextInt(10));
        }

        return builder.toString();
    }

    /**
     *A method that Generates a message hash
     */
    public String generateMessageHash(String messageId, int messageIndex, String message) {
        String prefix = messageId.substring(0, 2);
        String firstWord = message.split(" ")[0];
        String lastWord = message.split(" ")[message.split(" ").length - 1];

        return (prefix + ":" + messageIndex + ":" + firstWord + lastWord).toUpperCase();
    }

    /**
     * A method that Checks message length 
     */
    public boolean checkMessageLength(String message) {

        if (message.length() <= 50) {
            System.out.println("Message accepted.");
            return true;
        } else {
            System.out.println("Message too long. Please keep it under 50 characters.");
            return false;
        }
    }
    
        /**
     * A method that displays only SENT messages
     */
    public String displayOnlySentMessages(String messageId,String message,String messageHash,String recipient) {

        StringBuilder build = new StringBuilder();

 

            build.append("-------------------------\n")
                 .append("Message ID: ").append(messageId).append("\n")
                 .append("Message Hash: ").append(messageHash).append("\n")
                 .append("Recipient: ").append(recipient).append("\n")
                 .append("User Message: ").append(message).append("\n")
                 .append("-------------------------\n");

        

        // If nothing was added
        if (build.length() == 0) {
            return "No messages were actually sent.";
        }

        return build.toString();
    }
        /**
     * A method that validates South African cell numbers
     * Must start with +27
     */
    public String checkCellNumber(String cellNumber) {

        if (cellNumber != null
                && cellNumber.startsWith("+27")
                && cellNumber.length() >= 12
                && cellNumber.matches("\\+27[0-9]+")) {

            System.out.println("Cell number successfully captured.");
            return "Valid";

        } else {

            System.out.println("Invalid cell number. It must start with +27.");
            return "Invalid";
        }
    }

    /**
     * A method that Stores messages to JSON file
     */
    public void storeMessage(String messageId, String messageText, String messageHash, String recipient) {

        File file = new File("messages.json");
        Gson gson = new Gson();

        // 1D array to store message details
        String[] messageData = new String[4];
        messageData[0] = messageId;
        messageData[1] = messageText;
        messageData[2] = messageHash;
        messageData[3] = recipient;

        try {
            if (!file.exists()) {
                file.createNewFile();
            }

            String json = gson.toJson(messageData);

            try (FileWriter writer = new FileWriter(file, true)) {
                writer.write(json);
                writer.write(System.lineSeparator());
            }

        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
    }

    /**
     * A method that Calculates total messages
     */
    public int calculateTotalMessages(int currentTotal) {
        return currentTotal;
    }
}