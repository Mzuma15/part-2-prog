package com.mycompany.programminparttwo;

import java.util.Scanner;

public class ProgramminPartTwo {
private static Scanner scanner = new Scanner(System.in);
    private static Login registeredUser = null;
    
    public static void main(String[] args) {
        System.out.println("=== Registration and Login System ===\n");
        
        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            int choice = getIntInput();
            
            switch (choice) {
                case 1:
                    register();
                    break;
                case 2:
                    login();
                    
                    //PART 2
                    
                    
                    
                    //declaring and initializing the menu option
        int menuOption = 0;

        Scanner scan = new Scanner(System.in);

        while (menuOption != 3) {

            System.out.println(
                    "Select an option:\n"
                    + "1. Send Messages\n"
                    + "2. View Sent Messages\n"
                    + "3. Exit Application"
            );

            System.out.print("User: ");
            menuOption = scan.nextInt();
            scan.nextLine(); // clear buffer

            //using switch for the menu options
            switch (menuOption) {
                case 1:
                    sendMessages();
                    break;

                case 2:
                    System.out.println("Feature coming soon...");
                    break;

                case 3:
                    System.out.println("Thank you for using the system.\nGoodbye!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid option. Please select between 1 and 3.");
                    break;
            }
        }
                    break;
                case 3:
                    exit = true;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
        scanner.close();

        
    }

    /**
     * A method that Captures and processes user messages
     */
    public static void sendMessages() {

        Scanner scan = new Scanner(System.in);

        Message messageService = new Message();

        System.out.print("How many messages do you want to process? ");
        int messageCount = scan.nextInt();
        scan.nextLine();

        // Arrays for storing message data
        String[] recipients = new String[messageCount];
        String[] messageIds = new String[messageCount];
        String[] messages = new String[messageCount];
        String[] messageHashes = new String[messageCount];
        String[] messageStatuses = new String[messageCount];

        int totalSentMessages = 0;

        for (int i = 0; i < messageCount; i++) {

            do {
                System.out.print("Enter recipient cell number for message " + (i + 1) + ": ");
                recipients[i] = scan.nextLine();

            } while (!messageService.checkCellNumber(recipients[i]).equals("Valid"));

            // Message validation
            do {
                System.out.print("Enter message content for message " + (i + 1) + ": ");
                messages[i] = scan.nextLine();
            } while (!messageService.checkMessageLength(messages[i]));

            // Generate Message ID
            messageIds[i] = messageService.generateMessageId();
            System.out.println("Generated Message ID: " + messageIds[i]);

            // Generate Message Hash
            messageHashes[i] = messageService.generateMessageHash(
                    messageIds[i], i, messages[i]
            );

            System.out.println("Generated Message Hash: " + messageHashes[i]);

            // Message status selection
            messageStatuses[i] = messageService.selectMessageAction(
                    messageIds[i],
                    messages[i],
                    messageHashes[i],
                    recipients[i]
            );

            totalSentMessages = messageService.calculateTotalMessages(totalSentMessages + 1);
        }

        System.out.println("Total messages sent: " + totalSentMessages);
    }
    
    
    
     private static void register() {
        System.out.println("\n=== Registration ===\n");
        
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        
        System.out.print("Enter Username (must contain underscore, max 5 chars): ");
        String username = scanner.nextLine();
        
        System.out.print("Enter Password (8+ chars, capital, number, special char): ");
        String password = scanner.nextLine();
        
        System.out.print("Enter Cell Phone Number (with international code, e.g., +27...): ");
        String phoneNumber = scanner.nextLine();
        
        registeredUser = new Login(firstName, lastName, username, password, phoneNumber);
        
        String registrationMessage = registeredUser.registerUser();
        System.out.println("\n" + registrationMessage);
        
        if (registrationMessage.equals("User registered successfully!")) {
            System.out.println("Your account has been created!");
        }
    }
    
    private static void login() {
        if (registeredUser == null) {
            System.out.println("\nNo user registered yet. Please register first.");
            return;
        }
        
        System.out.println("\n=== Login ===\n");
        
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
        
        String loginStatus = registeredUser.returnLoginStatus(username, password);
        System.out.println("\n" + loginStatus);
    }
    
    private static int getIntInput() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }
}
