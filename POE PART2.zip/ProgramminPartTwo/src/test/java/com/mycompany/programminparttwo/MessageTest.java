package com.mycompany.programminparttwo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test Class for Message
 * Based strictly on the provided test data and requirements
 */
public class MessageTest {

    // Create Message object to access methods
    Message message = new Message();

    
    @Test
    void testMessageLengthSuccess() {
        String msg = "Hi Mike, can you join us for dinner tonight?";

        boolean result = message.checkMessageLength(msg);

        assertTrue(result, "Message ready to send.");
    }

    @Test
    void testMessageLengthFailure() {
        // Message longer than 250 characters
        String msg = "A".repeat(260);

        boolean result = message.checkMessageLength(msg);

        assertFalse(result,
                "Message exceeds 250 characters by 10; please reduce the size.");
    }

   

    @Test
    void testValidRecipientNumber() {
        String result = message.checkCellNumber("+27718693002");

        assertEquals(
                "Cell phone number successfully captured.",
                result
        );
    }

    @Test
    void testInvalidRecipientNumber() {
        String result = message.checkCellNumber("08575975889");

        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                result
        );
    }

    

    @Test
    void testMessageHashGeneration() {
        String messageId = "0012345678";
        String messageText = "Hi Mike tonight";

        String hash = message.generateMessageHash(messageId, 0, messageText);

        // Expected from test data
        assertEquals("00:0:HITONIGHT", hash);
    }

  
    @Test
    void testMultipleMessageHashes() {

        String[] messages = {
                "Hi Mike tonight",
                "Hi Keegan payment received"
        };

        String messageId = "0012345678";

        for (int i = 0; i < messages.length; i++) {
            String hash = message.generateMessageHash(messageId, i, messages[i]);

            assertNotNull(hash);
            assertTrue(hash.contains(":"));
        }
    }

   

    @Test
    void testMessageIdCreation() {
        String messageId = message.generateMessageId();

        assertEquals(10, messageId.length());
    }

   

    @Test
    void testSendMessageOption() {
        String status = "Send Message";

        assertEquals("Message successfully sent.", 
                     "Message successfully sent.");
    }

    @Test
    void testDisregardMessageOption() {
        String status = "Disregard Message";

        assertEquals("Press O to delete the message.", 
                     "Press O to delete the message.");
    }

    @Test
    void testStoreMessageOption() {
        assertDoesNotThrow(() -> {
            message.storeMessage(
                    "0012345678",
                    "Hi Mike",
                    "00:0:HIMIKE",
                    "+27718693002"
            );
        });

        assertEquals("Message successfully stored.",
                     "Message successfully stored.");
    }

   

    @Test
    void testTotalNumberOfMessages() {
        int total = message.calculateTotalMessages(2);

        assertEquals(2, total);
    }
}